function y_ahh = ahh_result( Bf, coe, x_0 )

[ dim, a, mb ] = size( Bf );
y_ahh = 0;
va = zeros( mb, 1 );

for i = 1 : mb    
    min_value = 1;
    for j = 1 : dim
        vector_b = Bf( j, :, i );
        if vector_b( 1 )~=0
            d_num = vector_b( 2 );
            temp_value = max( 0, vector_b( 1 ) * ( x_0( d_num ) - vector_b( 3 ) ) );
            if temp_value < min_value
                min_value = temp_value;
            end
        end
    end
    va( i ) = min_value;
    y_ahh = y_ahh + coe( i ) * min_value;
end