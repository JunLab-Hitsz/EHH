% narx3.m
% program for nonlinear autoregression exogenous system 3: example 3 in
% Wen's paper

clear
% clc
close all

%--parameter configuration
% load('/Users/Jun/Downloads/EHH/data/narendra2.mat');
L = 2000;
[u, yout, u_v, y_v ] = data_generation_narendra(L);

config_file = 'config.ini';
parameters = init_par(config_file);
penalty = parameters.penalty;  % complexity penalty
epsilon = 1e-3;  % precision ofr EHH optimization

%--obtain the regressors---

u_interval = [min(u), max(u)];
y_interval = [min(yout), max(yout)];

u_id = 1 : 3;
y_id = 1 : 3;

[phi, yphi] = arrange_phi(u, yout, u_id, y_id, u_interval, y_interval);

%--ten times optimization--
Err_sim_EHH_0 = zeros( 10, 1);
Err_sim_EHH = zeros( 10, 1);
Num_nn = zeros( 10, 1);
train_times = zeros( 10, 1);
Duration = zeros( 10, 1);

for counts = 1:2000
    
    
    
    
    
    %---identification result with the EHH procedure
    t1 = clock;
    
    [B_first, weights, id_var_bb, stem_B, adjacency_matrix, lof0, err0, lambda_opt] = Ini_network(phi, yphi, parameters);
    flag = 1;
    [err0, lof0]
    [~,y_ehh] = sys_simulation_ehh_phi(u_id, y_id, u_v, y_v, B_first, stem_B, weights, u_interval, y_interval);
    
    num_M = size(stem_B, 1);
    
    Err_sim_EHH_0(counts)  = norm( y_ehh - y_v' )^2 / norm( y_v' - mean( y_v' ) )^2;
    
    k_train = 0;
    
    while flag
        k_train = k_train + 1;
%         [stem_B, adja, lof, err]=Structue_optimization(B_first, stem_B, adjacency_matrix, id_var_bb, weights, phi,yphi,err0, parameters);
        [stem_B, adja, id_var_bb, lof, err]=Structue_optimization2(B_first, stem_B, adjacency_matrix, id_var_bb, weights, phi,yphi,err0, parameters);
        %         [~, yahh] = sys_simulation_ehh(na, nb, u_v, B_first, stem_B, weights, u_interval, y_interval,ulag);
        %         sqrt(norm( yahh - y_test )^2 / Ntest)%norm( y_test - mean( y_test ) )^2;%sqrt(/Ntest);%
        [ err, lof]
        [B_first, BB, stem_B, adjacency_matrix, id_var_bb, weights, lof, err]=weights_optimization(B_first, stem_B, id_var_bb, phi, yphi, lambda_opt, parameters);
        %         [~, yahh] = sys_simulation_ehh(na, nb, u_v, B_first, stem_B, weights, u_interval, y_interval,ulag);
        %         sqrt(norm( yahh - y_test )^2 / Ntest)%norm( y_test - mean( y_test ) )^2;%sqrt(/Ntest);%
        [ err, lof ]
        if lof<(1-epsilon)*lof0
            flag = 1;
            lof0 = lof;
            err0 = err;
        else
            flag = 0;
        end
    end
    
    t2 = clock;
    
    
    % test error for AHH algorithm
    
    [~,y_ehh] = sys_simulation_ehh_phi(u_id, y_id, u_v, y_v, B_first, stem_B, weights, u_interval, y_interval);
    
    Err_pre_ehh  = norm( y_ehh - y_v' )^2 / norm( y_v' - mean( y_v' ) )^2;
    
    if Err_pre_ehh<0.109
        dbstop at 88
    end
    
    M0( counts )=num_M;
    B1{ counts } = B_first;
    Err_sim_EHH( counts ) = Err_pre_ehh;
    train_times( counts ) = k_train;
    Duration( counts ) = etime(t2, t1);
    Num_nn( counts ) = length(weights)-1;
    ADJA{counts} = adja;
    WEIGHT{counts} = weights;
    
end

figure
axes( 'Fontsize',18)
plot( y_ehh, 'r','linewidth',1.5 )
hold on
plot( y_v,':','linewidth',1.5)
xlabel('t','fontsize',24 )
ylabel('y','fontsize',24 )
legend('EHH simulated output', 'System output')



