clear
close all
%% generate the train data and test data
load('/Users/Jun/Downloads/EHH/data/bouc-wen.mat');
na=15;%1;
nb=15;
dbstop if error

u_interval = [min(u), max(u)];
y_interval = [min(y), max(y)];
uval_multisine = uval_multisine';
yval_multisine = yval_multisine';
uval_sinesweep = uval_sinesweep';
yval_sinesweep = yval_sinesweep';

ulag = 0;
u = reshape(u,8192,5);
y = reshape(y,8192,5);
[phi, yphi]=arrange_uy(u(:), y(:), na, nb, u_interval, y_interval,ulag);

dim = size(phi,2);
Ntrain=length(yphi);

Ntest1=length(yval_multisine);
Ntest2=length(yval_sinesweep);
x_train=phi;
y_train=yphi;





%% Parameter Initialiation
config_file = 'config.ini';
parameters = init_par(config_file);
penalty = parameters.penalty;  % complexity penalty
num_train = parameters.num_train;  % number of training
percent = parameters.percent; % percentage of training data
parameters.lambda=[1e-9,1e-8,1e-7,1e-6];%; should be tuned for specific problem?
parameters.num_nn=0;


%%--EHH network optimization--


[B, weights, id_var_bb, stem_B, adjacency_matrix, id_layer, lof, err, stds, lambda_opt] = forward(x_train, y_train, parameters);

[sigma, minusgcv] = anova_ehh2(B, id_layer, stem_B, id_var_bb, weights, x_train, y_train, parameters);
       [~,bb]=sort(sigma(:,2),'descend');
       [sigma(bb,:),minusgcv(bb,2)]






[~,ysim1] = sys_simulation_ehh(na, nb, uval_multisine, B_first, stem_B, weights, u_interval, y_interval,ulag);
[~,ysim2] = sys_simulation_ehh(na, nb, uval_sinesweep, B_first, stem_B, weights, u_interval, y_interval,ulag);
err_sim1 = sqrt(norm(ysim1-yval_multisine)^2/Ntest1)
err_sim2 = sqrt(norm(ysim2-yval_sinesweep)^2/Ntest2)

[sigma, minusgcv] = anova_ehh(layers, weights, phi, yphi, parameters);
[~,bb]=sort(sigma(:,2),'descend');
[sigma(bb,:),minusgcv(bb,2)]



% 
% 
% figure
% plot(y_test,'k:','linewidth',1.5)
% hold on
% plot(yahh,'linewidth',1.5)
% xlabel('Times Instant','fontsize',14)
% ylabel('The outputs','fontsize',14)
% 
% 
% 

