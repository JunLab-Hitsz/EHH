function [phi, yphi, u_v, y_v,umin, umax, ymin, ymax]=data_generation_narx2(na,nb)
%- na is the assumed lag for u
%- nu is the actual lag for u
%- nb is the assumed lag for y
%- ny is the actual lag for y
%- u and y are all in 1-dimension, for multiple dimensions, later

Lt=1200; % length for train data
Lv=800;  % length for test data
nu=1;
ny=1;

%% train data generation
yout = zeros(Lt, 1);
ns1 = max(nu, ny);

for t = 1 : Lt
    u( t ) = sin(pi*t/50)+sin(pi*t/20);
end


for t = ns1+1 : Lt
    yout( t ) = yout(t-1)/(1 + (yout(t-1))^2)+ (u(t-1))^3;
end

umin = floor(min(u));
umax = ceil(max(u));
ymin = floor(min(yout));
ymax = ceil(max(yout));
%% test data generation
y_v = zeros(Lv, 1);
u_v = y_v;

for t = 1 : Lv
    u_v( t ) = 0.9*sin(pi*t/50) + 1.1*sin(pi*t/20);
end




for t = ns1+1 : Lv
    y_v( t ) = y_v(t-1)/(1 + (y_v(t-1))^2)+ (u_v(t-1))^3;
end

% u_v = (u_v-umin)/(umax-umin);
% y_v = (y_v-ymin)/(ymax-ymin);

%% arranged train data
nstart = max(na,nb);


u = reshape(u,Lt,1);
y = reshape(yout,Lt,1);
% u = (u-umin)/(umax-umin);
% y = (y-ymin)/(ymax-ymin);
for t=nstart+1:Lt
    id=t-nstart;
    reg1 = (y(t-1:-1:t-nb)-ymin)/(ymax - ymin);
    reg2 = (u(t-1:-1:t-na)-umin)/(umax - umin);
    phi(id,:)=[reg1', reg2'];
end
yphi=y(nstart+1: Lt);