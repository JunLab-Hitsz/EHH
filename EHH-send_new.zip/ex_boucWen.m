%--ex_boucWen.m---
clear
close all
%% generate the train data and test data
load('/Users/Jun/Downloads/EHH/data/bouc-wen.mat');
na=15;%1;
nb=15;
% na = [];
% nb = [1 2 4];

% uval_multisine = uval_multisine';
% yval_multisine = yval_multisine';
% uval_sinesweep = uval_sinesweep';
% yval_sinesweep = yval_sinesweep';

u_interval = [min(u), max(u)];%[-205,210];%
y_interval = [min(y), max(y)];%[-0.0025,0.0025];%
% u = (u-u_interval(1))/(u_interval(2)-u_interval(1));
% y = (y-y_interval(1))/(y_interval(2)-y_interval(1));
uval_multisine = uval_multisine';%-u_interval(1))/(u_interval(2)-u_interval(1));
yval_multisine = yval_multisine';%-y_interval(1))/(y_interval(2)-y_interval(1));
uval_sinesweep = uval_sinesweep';%-u_interval(1))/(u_interval(2)-u_interval(1));
yval_sinesweep = yval_sinesweep';%-y_interval(1))/(y_interval(2)-y_interval(1));

ulag = 1;
u = reshape(u,8192,5);
y = reshape(y,8192,5);
[phi, yphi]=arrange_uy(u(:), y(:), na, nb, u_interval, y_interval,ulag);

dim = size(phi,2);
Ntrain=length(yphi);

Ntest1=length(yval_multisine);
Ntest2=length(yval_sinesweep);


%% Parameter Initialiation
config_file = 'config.ini';
parameters = init_par(config_file);
penalty = parameters.penalty;  % complexity penalty
num_train = parameters.num_train;  % number of training
percent = parameters.percent; % percentage of training data
parameters.lambda=[1e-8,1e-7,1e-6,1e-5];%; should be tuned for specific problem?

%%
num_train = 10;%10;%100;%floor(Ntrain/ns);
adjacency_matrices = cell(num_train, 1);
stem_BBs = cell(num_train, 1);
Bs = cell(num_train, 1);
Bs_first = cell(num_train, 1);
layer_indices = cell(num_train, 1);
weights_all = cell(num_train, 1);
lofs = zeros(num_train, 1);
errs = zeros(num_train, 1);
stds_all = zeros(num_train, 1);
yahh1 = zeros(length(yval_multisine), num_train);
yahh2 = zeros(length(yval_sinesweep), num_train);
err_test1 = zeros(num_train, 1);
err_test2 = err_test1;
std_test1 =  zeros(num_train, 1);
std_test2 = std_test1;
%
u_v = u(:);
x_v = phi;
y_v = yphi;
structure_candidate={0,[20],[20 20],[20 20 20 20]};%,[100],[100,100]};%, [20]};%,50};%, 50, [50, 50]};%,[50]};0,[100],
nstructure=length(structure_candidate);


for rr = 1:1
%     data_id = 2;
%     [phi, yphi]=arrange_uy(u(:,data_id), y(:,data_id), na, nb, u_interval, y_interval,ulag);
%     indices = crossvalind('Kfold',length(yphi),num_train);
    ns = length(yphi)-1000:100:length(yphi)-1;%
%length(yphi)-10:length(yphi)-1;

    tic;
    for kk = 1:num_train   %num_train is the training times
%         id_leave = (indices == kk);
%         id_left = ~id_leave;
%         x_train = phi(id_left,:);
%         y_train = yphi(id_left);
        x_train = phi(1:ns(kk), :);
        y_train = yphi(1:ns(kk));
        lTT=randi(nstructure);
        parameters.structure=structure_candidate{lTT};
        
        
        [B, weights, id_var_bb, stem_B, adjacency_matrix, id_layer, lof, err, stds, lambda_opt] = forward(x_train, y_train, parameters);
        
        
        num_nodes=size(stem_B,1);
        pos_row_id = find(stem_B(:,1)>0);  %positive row index, the rows for the first hidden layer are zero
        if isempty(pos_row_id)   % all the neurons are in the first hidden layer
            num1layer = num_nodes;
        else
            num1layer = num_nodes - length(pos_row_id);  % number of nodes in the first hidden layer
        end
        B_first = cell2mat(B(1:num1layer));  % basis function matrix in the first hidden layer
        
        
        Bs_first{kk} = B_first;
        adjacency_matrices{kk} = adjacency_matrix;
        stem_BBs{kk} = stem_B;
        Bs{kk} = B;
        layer_indices{kk} = id_layer;
        LAYERS{kk}=[B, num2cell(id_layer,2), num2cell(stem_B,2)];
        %     LAYERS=LAYERS';
        weights_all{kk} = weights;
        
        lofs(kk)  = lof;
        errs(kk) = err;
        stds_all(kk) = stds;
        
        %     yahh1(:,TT) = sys_simulation_ehh(na, nb, uval_multisine, yval_multisine, B, stem_B, weights, u_interval,y_interval,ulag);
        %     yahh2(:,TT) = sys_simulation_ehh(na, nb, uval_sinesweep, yval_sinesweep, B, stem_B, weights, u_interval, y_interval,ulag);
        %
        %     err_test1(TT) = sqrt(norm( yahh1(:,TT) - yval_multisine )^2/Ntest1);% / norm( yval_multisine - mean( yval_multisine ) )^2;
        %     std_test1(TT) = std( yahh1(:,TT) - yval_multisine);
        %
        %     err_test2(TT) = sqrt(norm( yahh2(:,TT) - yval_sinesweep )^2/Ntest2);% / norm( yval_multisine - mean( yval_multisine ) )^2;
        %     std_test2(TT) = std( yahh2(:,TT) - yval_sinesweep);
        
        %sys_simulation_ehh(na, nb, u, y, umin, umax, ymin, ymax, B, stem_B, weights);%
        f_ehh_TT(:,kk)= cal_node_value(B,stem_B,x_v)*weights;%x_validate
    end
    
 
    P=2*f_ehh_TT'*f_ehh_TT;
    P=(P+P')/2;
    q=-2*f_ehh_TT'*y_v;%y_validate;
    r=y_v'*y_v;%validate;
    lb=zeros(num_train,1);
    [ratio,~]=quadprog(P, q, [], [],[],[],lb, []);
    
    id_non0=find(ratio>1e-5);
    LAYERS = reshape(LAYERS,num_train,1);
    weights_all = reshape(weights_all,num_train,1);
    [layers, weights] = merge_net2(LAYERS(id_non0,:), weights_all(id_non0,:), ratio(id_non0), parameters );
       %     [xsim, ysim] = sys_simulation_ehh(na, nb, u_v, B_tt, stem_B_tt, weights, u_interval, y_interval,ulag);
       [sigma, minusgcv] = anova_ehh(layers, weights, x_v, y_v, parameters);
       [~,bb]=sort(sigma(:,2),'descend');
       [sigma(bb,:),minusgcv(bb,2)]
time_gen(rr)=toc;
    B_tt=layers(:,1);
    stem_B_tt = cell2mat(layers(:,3));
    id_layer_tt= cell2mat(layers(:,2));
    num_para(rr) = size(B_tt,1)*3+1;

    [~,ysim1] = sys_simulation_ehh(na, nb, uval_multisine, B_tt, stem_B_tt, weights, u_interval, y_interval,ulag);
    [~,ysim2] = sys_simulation_ehh(na, nb, uval_sinesweep, B_tt, stem_B_tt, weights, u_interval, y_interval,ulag);
    
    err_sim1(rr) = sqrt(norm(ysim1-yval_multisine)^2/Ntest1);%*(y_interval(2)-y_interval(1));
    err_sim2(rr) = sqrt(norm(ysim2-yval_sinesweep)^2/Ntest2);;%*(y_interval(2)-y_interval(1));
    
    ypre1 = sys_prediction_ehh(na, nb, uval_multisine, yval_multisine, B_tt, stem_B_tt, weights, u_interval, y_interval,ulag);
    ypre2 = sys_prediction_ehh(na, nb, uval_sinesweep, yval_sinesweep, B_tt, stem_B_tt, weights, u_interval, y_interval,ulag);
    
    err_pre1(rr) = sqrt(norm(ypre1-yval_multisine)^2/Ntest1);%*(y_interval(2)-y_interval(1));
    err_pre2(rr) = sqrt(norm(ypre2-yval_sinesweep)^2/Ntest2);%*(y_interval(2)-y_interval(1));
end
figure
plot(yval_multisine(7001:end),':','linewidth',1.5)
hold on
plot(ysim1(7001:end),'linewidth',1.5)
xlabel('Times Instant','fontsize',14)
ylabel('The outputs','fontsize',14)

figure
plot(yval_sinesweep,':','linewidth',1.5)%(7001:end)
hold on
plot(ysim2,'linewidth',1.5)
xlabel('Times Instant','fontsize',14)
ylabel('The outputs','fontsize',14)


