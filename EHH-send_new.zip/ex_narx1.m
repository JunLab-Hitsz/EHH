%--ex_narx1.m---
clear
%% generate the train data and test data
% load('/Users/Jun/Downloads/EHH/data/narx1-auto.mat');
na=2;nu=2;
nb=3;ny=3;
umin=-1; umax=1;
ymin=-1.5; ymax=1.5;

for T_gen=1:100
    
    [phi, yphi, u_v, y_test]=data_generation_narx1(na,nb,nu,ny, umin, umax, ymin, ymax);
    
    dim = size(phi,2);
    dim_y = size(yphi,1);
    Ntrain=length(yphi);
    Ntest=length(y_test);
    
    
    %% Parameter Initialiation
    config_file = 'config.ini';
    parameters = init_par(config_file);
    penalty = parameters.penalty;  % complexity penalty
    num_train = parameters.num_train;  % number of training
    percent = parameters.percent; % percentage of training data
    parameters.lambda=[1e-6, 1e-5, 1e-4, 1e-3];%, 1e-2, 1e-1];%; should be tuned for specific problem?
    %%
    ns = 7900;%number of samples used for single network generation
    num_train=10;%floor(Ntrain/ns);
%     x_validate=phi(401:end,:);%phi(num_train*ns+1:end,:);
%     y_validate=yphi(401:end);%yphi(num_train*ns+1:end);
    % num_train=10;
    % indices = crossvalind('Kfold',Ntrain,num_train);
    
    structure_candidate={[20], [20 20]};
    nstructure=length(structure_candidate);
    
    adjacency_matrices = cell(num_train, 1);
    stem_BBs = cell(num_train, 1);
    Bs = cell(num_train, 1);
    Bs_first = cell(num_train, 1);
    layer_indices = cell(num_train, 1);
    weights_all = cell(num_train, 1);
    lofs = zeros(num_train, 1);
    errs = zeros(num_train, 1);
    stds_all = zeros(num_train, 1);
    yahh = zeros(length(y_test), num_train);
    err_test = zeros(num_train, 1);
    std_test =  zeros(num_train, 1);
    indices = crossvalind('Kfold',ns,num_train);
    
    for TT = 1:num_train   %num_train is the training times
        %     interval=1:790;%(TT-1)*ns+1:TT*ns;
        %     x_train=phi(interval,:);
        %     y_train=yphi(interval);
        id_leave = (indices == TT);
        id_left = ~id_leave;
        x_train=phi(id_left,:);
        y_train=yphi(id_left);
        lTT=randi(nstructure);
        parameters.structure=structure_candidate{lTT};
        
        [B, weights, id_var_bb, stem_B, adjacency_matrix, id_layer, lof, err, stds, lambda_opt] = forward(x_train, y_train, parameters);
        
        
        num_nodes=size(stem_B,1);
        pos_row_id = find(stem_B(:,1)>0);  %positive row index, the rows for the first hidden layer are zero
        if isempty(pos_row_id)   % all the neurons are in the first hidden layer
            num1layer = num_nodes;
        else
            num1layer = num_nodes - length(pos_row_id);  % number of nodes in the first hidden layer
        end
        B_first = cell2mat(B(1:num1layer));  % basis function matrix in the first hidden layer
        
        
        Bs_first{TT} = B_first;
        adjacency_matrices{TT} = adjacency_matrix;
        stem_BBs{TT} = stem_B;
        Bs{TT} = B;
        layer_indices{TT} = id_layer;
        LAYERS{TT}=[B, num2cell(id_layer,2), num2cell(stem_B,2)];
        LAYERS=LAYERS';
        weights_all{TT} = weights;
        
        lofs(TT)  = lof;
        errs(TT) = err;
        stds_all(TT) = stds;
       
       
        yahh(:,TT) = sys_simulation_ehh(na, nb, u_v, y_test, umin, umax, ymin, ymax, B, stem_B, weights);
        err_test(TT) = norm( yahh(:,TT) - y_test )^2 / norm( y_test - mean( y_test ) )^2;%sqrt(/Ntest);%
        std_test(TT) = std( yahh(:,TT) - y_test);
        
        f_ehh_TT(:,TT)=cal_node_value(B,stem_B,x_train)*weights;%x_validate
        
    end
    P=2*f_ehh_TT'*f_ehh_TT;
    P=(P+P')/2;
    q=-2*f_ehh_TT'*y_train;%y_validate;
    r=y_train'*y_train;%validate;
    lb=zeros(num_train,1);
    [ratio,~]=quadprog(P, q, [], [],[],[],lb, []);
    
    id_non0=find(ratio>1e-5);
    [layers, weights] = merge_net2(LAYERS(id_non0,:), weights_all(id_non0,:), ratio(id_non0), parameters );
    B_tt=layers(:,1);
    stem_B_tt=cell2mat(layers(:,3));
    id_layer_tt=cell2mat(layers(:,2));
    yt = sys_simulation_narx1(na, nb, u_v, y_test, umin, umax, ymin, ymax, B_tt, stem_B_tt, weights);
    
    yt=yahh*ratio;
    err_gen(T_gen)=norm(yt-y_test)^2/norm(y_test-mean(y_test))^2;
end




