function [ BBf, Bf, coe, errm ] = ahh( dim, b_left, b_right, x, y, shares, mi, Mmax)
% 
% AHH algorithm including the backward stepwise
% GCV be the criterion
% 
% input 
%       dim        --- the dimension of the problem
%       b_left   --- the interval points
%       b_right  --- the interval points
%       N        --- the sample size
%       x        --- the sample x, with size N x dim
%       y        --- the sample y, with size N x 1
%       shares   --- the number of points interpolate in the interval
%       mi       --- mi <= n
%       Mmax     --- the maximum number of basis functions, larger Mmax
%                    leads to smaller approximation error
% output
%       BBf      --- the basis function evaluated at the points
%       Bf       --- the parameters of the basis function
%       coe      --- the coefficient matrix, dim x 1

N = size( x, 1 );
BB = []; B = [];                    %BB is the basis data matrix,BB(i,j)=Bi(Xj)
BB( 1 , : ) = ones( 1 , N );         %BB(1,:) is the data matrix for constant bais B(:,:,1)
% knots= ( [ 1 : 1 : shares ] - 1 ) / shares * ( b_right - b_left );
knots = linspace( b_left + ( b_right - b_left ) / shares, b_right - ( b_right - b_left ) / shares, shares - 1 );
% knots = zeros( 1, max( shares) - 1, dim );
% for i = 1 : dim
%     knots( :, 1 : shares( i ) - 1, i ) = linspace( b_left + ( b_right - b_left ) / shares( i ), b_right - ( b_right - b_left ) / shares( i ), shares( i ) - 1 );
% end
n = dim;
M = 2; 
num = 1; 
d = 1;


len_knots = shares - 1;

B = zeros(mi, 3, Mmax);

while num < Mmax
    lofm = 1e8;
    for m = 1 : num
        temp0 = B( : , : , m );
        temp = [];
        n1_temp = 0;
        for k = 1 : mi
            if temp0( k , 1 ) ~= 0
                temp = [ temp; temp0( k, : ) ];
                n1_temp = n1_temp + 1;
            end
        end
        if n1_temp <= mi - 1
            for i = 1 : n
                for j = 1 : len_knots%( i )
                    if ~ismember( i ,temp0( : , 2 ) )
                        ad1 = min( BB( m , : ) , max(  x( : , i ) - knots( j )  , 0 )' );% knots( 1, j, i )
                        ad2 = min( BB( m, : ), max( -( x( :, i ) - knots( j ) ) , 0 )' );% knots( 1, j, i )
                        bb = [ BB ; ad1; ad2 ];
                        C = rank( bb );
                        C0 = rank( BB );
                        C1 = rank( [ BB; ad1 ] );
                        C2 = rank( [ BB; ad2 ] );
                        if C > C0
                            if C == C1
                                bb = [ BB; ad1 ];
                                ch = 1;
                                ad_num_0 = 1;
                            elseif C == C2
                                bb = [ BB; ad2 ];
                                ch = 2;
                                ad_num_0 = 1;
                            else
                                ad_num_0 = 2;
                                ch = 0;
                            end 
                            M = size( bb , 1 ) - 1;
                            err = norm( y - bb' * ( bb' \ y ) )^2;
                            lof = 1 / N * err / ( 1 - ( M + 1 + d * M ) / N )^2;
                            if lof < lofm
                                lofm = lof;
                                mm = m;
                                vm = i;
                                tm = knots( j ); %knots( 1, j, i );
                                tempm = temp;
                                chc = ch;
                                ad_num = ad_num_0;
                            end
                        end
                    end
                end
            end
        end
    end
    if ad_num == 2
        if mm == 1
            B( :, :, num + 1 ) = [ 1, vm, tm ; zeros( mi - 1, 3 )];
            B( :, :, num + 2 ) = [ -1, vm, tm ; zeros( mi - 1, 3 )];
        elseif size( tempm, 1 ) == mi - 1
            B( :, :, num + 1 ) = [ tempm; 1, vm, tm ];
            B( :, :, num + 2 ) = [ tempm; -1, vm, tm ];
        else
            zein = mi - size( tempm, 1 ) - 1;
            B( :, :, num + 1 ) = [ tempm; 1, vm, tm; zeros( zein, 3 ) ];
            B( :, :, num + 2 ) = [ tempm; -1, vm, tm; zeros( zein, 3 ) ];
        end
        BB( num + 1 , : ) = min( BB( mm, : ) , max( ( x( : , vm ) - tm ) , 0 )' );
        BB( num + 2 , : ) = min( BB( mm, : ), max( - ( x( :, vm ) - tm )', 0 ) );
    elseif ad_num == 1
        if chc == 1   
            if mm == 1
                B( :, :, num + 1 ) = [ 1, vm, tm ; zeros( mi - 1, 3 )];
            elseif size( tempm, 1 ) == mi - 1
                B( :, :, num + 1 ) = [ tempm; 1, vm, tm ];
            else
                zein = mi - size( tempm, 1 ) - 1;
                B( :, :, num + 1 ) = [ tempm; 1, vm, tm; zeros( zein, 3 ) ];
            end
            BB( num + 1, : ) = min( BB( mm, : ), max( ( x( :, vm ) - tm ), 0 )' );
        elseif chc == 2
            if mm == 1
                B( :, :, num + 1 ) = [ -1, vm, tm ; zeros( mi - 1, 3 )];
            elseif size( tempm, 1 ) == mi - 1
                B( :, :, num + 1 ) = [ tempm; -1, vm, tm ];
            else
                zein = mi - size( tempm, 1 ) - 1;
                B( :, :, num + 1 ) = [ tempm; -1, vm, tm; zeros( zein, 3 ) ];
            end
            BB( num + 1, : ) = min( BB( mm, : ), max( -( x( :, vm ) - tm ), 0 )' );
        end
    end            
    num = num + ad_num;
end

Mb = size( BB , 1 );
err = norm( y - BB' * ( BB' \ y ) )^2;
errm = err / norm( y - mean( y ) )^2;
lofm = 1 / N * err / ( 1 - ( Mb + d * ( Mb - 1) ) / N )^2;

% backward
% Mmax = size(BB,1); % very important, was wrong the first time and the solution errm_f was different from those in eg1o.m
Jm = 1 : Mb;          %Jm is the set of basis functions give the optimal lof
Km = Jm;
for M = Mb : -1 : 2       %each interation of M causes one basis function to be deleted
    b = 1e8;
    L = Km;
    for m = 2 : M         %choose which one, it is the one whose removal either improves the fit the most or degrades
        K = [ L( 1 : m - 1 ) , L( m + 1 : size( L , 2 ) ) ];   %it the least
        BBk = BB( K , : );   %very important, was wrong before
        C = rank( BBk );
        err = norm( y - BBk' * ( BBk' \ y ) )^2;
        lof = 1 / N * err / ( 1 - ( C + d * ( M - 1 ) ) / N )^2;
        if lof < b
            b = lof;
            Km = K;    %Km is the set of basis functions give the optimal lof in the descending sequence
        end
        if lof < lofm
            lofm = lof;
            errm = err;
            Jm = K;   % 1 is very important for the constant basis was never deleted   
        end
    end
end

BBf = BB( Jm , : );
Bf = B( : , : , Jm );
coe = BBf' \ y ;
errm = norm( y - BBf' * coe )^2 / norm( y - mean( y ) )^2;

