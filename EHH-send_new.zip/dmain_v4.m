%dmain2.m

clear

dbstop if error
%% load the data
data_files = { 'fried_delve_std.data'; 'abalone_std.data'; 'cal_housing_std.data'; 'cart_delve_std.data'; 
    'cpusmall_std.data'; 'kin8nm_std.data'; 'r_wpbc_std.data'; 'space_ga_std.data'; };
data_file = data_files{3};
config_file = 'config.ini';

A = textread(strcat('./data/' , data_file));  % every row stands for a sample, the last column is y

miny = min(A(:,end));
maxy = max(A(:,end));
A(:,end) = (A(:,end)-miny)/(maxy-miny);  %you can finish this step by modifyling the data file


%% Parameter Initialiation
parameters = init_par(config_file);
penalty = parameters.penalty;  % complexity penalty
num_train = parameters.num_train;  % number of training
percent = parameters.percent; % percentage of training data
lambda = parameters.lambda;
%% Training set and Test set
[x_train, y_train, x_validate, y_validate, x_test, y_test] = validate_data(A, percent);

dim = size(x_train,2);
dim_y = size(y_train,2);
%%
% ns = 2000;%size(x_train,1);%2000;%floor(size(x_train,1)/2);%2000;
% x_ekf=x_train;%(ns+1:2*ns,:);
% y_ekf=y_train;%(ns+1:2*ns,:);


adjacency_matrices = cell(num_train, 1);
stem_BBs = cell(num_train, 1);
Bs = cell(num_train, 1);
Bs_first = cell(num_train, 1);
layer_indices = cell(num_train, 1);
weights_all = cell(num_train, 1);
lofs = zeros(num_train, 1);
errs = zeros(num_train, 1);
stds_all = zeros(num_train, 1);
yahh = zeros(length(y_test), num_train);
err_test = zeros(num_train, 1);
std_test =  zeros(num_train, 1);
for TT = 1:num_train   %num_train is the training times

% [B1,B,coef,id_var_bb, stem_B,Adja,id_layer,t] = forward_batch(x_train, y_train, shares, epsilon,lambda);
% [B1,B,coef,id_var_bb, stem_B,Adja,id_layer,lof,t] = forward_v4(x_train, y_train, shares, structure_parameter);
% [B1,B,coef,id_var_bb, stem_B,Adja,id_layer,lof,rt] = forward_v4(x_struct, y_struct, shares, structure_parameter);
[B, weights, id_var_bb, stem_B, adjacency_matrix, id_layer, lof, err, stds, lambda_opt] = forward(x_train, y_train, parameters);


num_nodes=size(stem_B,1);
pos_row_id = find(stem_B(:,1)>0);  %positive row index, the rows for the first hidden layer are zero
if isempty(pos_row_id)   % all the neurons are in the first hidden layer
    num1layer = num_nodes;
else
    num1layer = num_nodes - length(pos_row_id);  % number of nodes in the first hidden layer
end
B_first = cell2mat(B(1:num1layer));  % basis function matrix in the first hidden layer

% B_first=ekf_pwl(weights, B_first, stem_B, x_ekf, y_ekf, stds);
% lof = 10;
% stem_B0=stem_B;
% id_layer0=id_layer;
% id_var_bb0=id_var_bb;
% for k = 1:length(lambda)
%     [Bk, BBk, stem_Bk, Adjak, id_layerk, id_var_bbk, coefk, lofk, errk, stdsk] = prune_node(B_first, stem_B0, id_layer0, id_var_bb0, x_train, y_train,lambda(k), parameters);
%     execute_prune = 'X';
%     if lofk < lof
%         B = Bk;
%         BB = BBk;
%         stem_B = stem_Bk;
%         adjacency_matrix = Adjak;
%         id_layer = id_layerk;
%         id_var_bb = id_var_bbk;
%         weights = coefk;
%         lof = lofk;
%         execute_prune = 'ok';
%         lambda_opt=lambda(k);
%     end
% end



Bs_first{TT} = B_first;
adjacency_matrices{TT} = adjacency_matrix;
stem_BBs{TT} = stem_B;
Bs{TT} = B;
layer_indices{TT} = id_layer;
LAYERS{TT}=[B, num2cell(id_layer,2), num2cell(stem_B,2)];
LAYERS=LAYERS';
weights_all{TT} = weights;

lofs(TT)  = lof;
errs(TT) = err;
stds_all(TT) = stds;

node_values = cal_node_value(B,stem_B, x_test);
yahh(:,TT) = node_values*weights;
err_test(TT) = norm( yahh(:,TT) - y_test )^2 / norm( y_test - mean( y_test ) )^2;
std_test(TT) = std( yahh(:,TT) - y_test);

f_ehh_TT(:,TT)=cal_node_value(B,stem_B,x_validate)*weights;

end
P=2*f_ehh_TT'*f_ehh_TT;
q=-2*f_ehh_TT'*y_validate;
r=y_validate'*y_validate;
lb=zeros(num_train,1);
[ratio,~]=quadprog(P, q, [], [],[],[],lb, []);

id_non0=find(ratio>1e-6);
[layers, weights] = merge_net2(LAYERS(id_non0,:), weights_all(id_non0,:), ratio(id_non0), parameters );
B_tt=layers(:,1);
stem_B_tt=cell2mat(layers(:,3));
id_layer_tt=cell2mat(layers(:,2));
ytt=cal_node_value(B_tt, stem_B_tt, x_test)*weights;
ytt-yahh*ratio;
norm(ytt-y_test)^2/norm(y_test-mean(y_test))^2


