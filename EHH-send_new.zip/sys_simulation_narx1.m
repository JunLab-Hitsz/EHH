function ysim=sys_simulation_narx1(na, nb, u_v, y_v, umin, umax, ymin, ymax, B, stem_B, weights)

Lv = length(u_v);
ysim = zeros(Lv, 1);
y_v = reshape(y_v, length(y_v),1);

if length(na)==1 & length(nb)==1
    ns = max(na,nb);
    xsim = zeros(Lv, na+nb);

    for t = ns+1 : Lv
        reg1 = (ysim(t-1:-1:t-nb)-ymin)/(ymax - ymin);%(y_v(t-1:-1:t-nb)-ymin)/(ymax - ymin);
        reg2 = (u_v(t-1:-1:t-na)-umin)/(umax - umin);
        xsim( t, : ) = [ reg1', reg2'];
        ysim( t ) = cal_node_value( B, stem_B, xsim(t, :) )*weights;
    end
else
    if isempty(na)
        ns = max(nb);
    else
        ns = max(max(nb), max(na));
    end
    xsim = zeros(Lv, length(na)+length(nb));
    for t = ns+1:Lv
        reg1 = []; reg2 = reg1;
        for ii = 1: length(nb)
            reg1 = [reg1, (ysim(t-nb(ii))-ymin)/(ymax-ymin)];
        end
        for ii = 1:length(na)
            reg2 = [reg2, (u(t-na(ii))-umin)/(umax-umin)];
        end
        xsim( t, : ) = [reg1, reg2];
        ysim( t ) = cal_node_value( B, stem_B, xsim(t, :) )*weights;
    end
end
