function [id_var, sigma, minusgcv] = anova_ehh2(B_first, stem_B, adjacency, weights, x, y, parameters)


weights_nn = weights(2:end);

penalty = parameters.penalty;

node_values = cal_node_value(B_first, stem_B, x);
BB = node_values(:, 2:end);


f = node_values*weights;


num_nn = length(weights)-1;

Ir = adajcency2interaction( adjacency(:, 1:end-1) );

id_layer = max(1, sum(Ir, 1));
num_layer = max(id_layer);
k = 1;

for ll = 1 : num_layer
    id_nn_ll = find(id_layer == ll);  % the index of nodes in the ll-th layer
    nn_ll = node_values(:, id_nn_ll); % correpsonding nn values
    id_b1_ll = [];  %
    Ir_ll = Ir(:, id_nn_ll); % the columns in Ir with ll-th layer
    for jj = 1 : length(id_nn_ll)
        id_b1_ll = [id_b1_ll; find(Ir_ll(:, jj)>0)]; %index in terms of the source nodes
    end
    id_var_ll = reshape(B_first(id_b1_ll,2),ll, length(id_nn_ll)); % variables corresponding to each node in the ll-th layer
    id_var_ll = id_var_ll';
    id_var_ll = sort(id_var_ll, 2);
    id_var_uni = unique(id_var_ll, 'rows'); % the unique combination of variables in the ll-th layer
    for ii = 1:size( id_var_uni, 1) % for each combination, find the ANOVA function
        temp = id_var_ll - repmat(id_var_uni(ii, :), length(id_nn_ll), 1);
        temp1 = max(temp, [], 2);
        temp2 = min(temp, [], 2);
        id_temp = intersect(find(temp1==0), find(temp2==0)); % the id in id_nn that constitutes the ANOVA function
        id_ii = id_nn_ll(id_temp);
        stem_Bii = stem_B(id_ii,:);
        weights_ii = weights_nn(id_ii);
        fii = BB(:,id_ii)*weights_ii;
        id_var{k} = id_var_uni(ii, :);
        num_nodes = num_nn-length(id_ii);
        sigma(k,:) = sqrt(var(fii));
        fminus = f-fii;
        cm = num_nodes+1;%trace(BBminus*inv(BBminus'*BBminus)*BBminus')+1;
        minusgcv(k,:) = norm(fminus-y)^2 / ( 1 - ( cm + penalty * num_nodes ) / size(x, 1) )^2/norm(y-mean(y))^2;
        k = k +1;
    end
end




