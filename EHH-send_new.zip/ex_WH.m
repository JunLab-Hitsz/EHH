%--ex_WH.m---
clear
close all
%% generate the train data and test data
% load('/Users/Jun/Downloads/EHH/data/WH1.mat');
% data1 = load('/Users/Jun/Downloads/EHH/data/WH_Triangle2_meas.mat');
data1 = load('/Users/Jun/Downloads/EHH/data/WH_EstimationExample.mat');
data2 = load('/Users/Jun/Downloads/EHH/data/WH_TestDataset.mat');

u_train = data1.dataMeas.u;
yy_train = data1.dataMeas.y;
u_test = data2.dataMeas.u;
y_test = data2.dataMeas.y;
u_interval = [-3,3.5];
y_interval = [-0.32,0.35];

na=2;%10;%2;
nb=3;%3;

uval1 = u_test(:,1);
uval2 = u_test(:,2);
yval1 = y_test(:,1);
yval2 = y_test(:,2);
Ntest1 = length(yval1);
Ntest2 = length(yval2);

%% Parameter Initialiation
config_file = 'config.ini';
parameters = init_par(config_file);
penalty = parameters.penalty;  % complexity penalty
num_train = parameters.num_train;  % number of training
percent = parameters.percent; % percentage of training data
parameters.lambda=[1e-5, 1e-4, 1e-3];%, 1e-2, 1e-1];%; should be tuned for specific problem?

%% Identification and evaluation
for T_gen=1:1
    d = T_gen;
    [phi, yphi, umin, umax, ymin, ymax]=arrange_uy(u_train(:,d),yy_train(:,d),na,nb,u_interval,y_interval);

    
    dim = size(phi,2);
    dim_y = size(yphi,1);
    Ntrain = length(yphi);
  
    
    
 
    %%
    
    num_train=10;%100;%floor(Ntrain/ns);
    
%     ns = floor(Ntrain/num_train)*num_train;%7900;%number of samples used for single network generation
%     indices = crossvalind('Kfold',ns,num_train);
    ns = 6200:200:8000;%floor(Ntrain/num_train)*num_train;%7900;%number of samples used for single network generation
    x_v = phi;
    y_v = yphi;
    
    
    structure_candidate = {0,[50],[50,50],[50,50,50]};%,[50], [50 50]};
    nstructure=length(structure_candidate);
    
    adjacency_matrices = cell(num_train, 1);
    stem_BBs = cell(num_train, 1);
    Bs = cell(num_train, 1);
    Bs_first = cell(num_train, 1);
    layer_indices = cell(num_train, 1);
    weights_all = cell(num_train, 1);
    lofs = zeros(num_train, 1);
    errs = zeros(num_train, 1);
    stds_all = zeros(num_train, 1);
    yahh1 = zeros(Ntest1, num_train);
    yahh2 = zeros(Ntest2, num_train);
    err_test1 = zeros(num_train, 1);
    err_test2 = err_test1;
    std_test1 =  zeros(num_train, 1);
    std_test2 = err_test2;
        tic

    for TT = 1:num_train   %num_train is the training times
        %     interval=1:8000;%(TT-1)*ns+1:TT*ns;
        %     x_train=phi(interval,:);
        %     y_train=yphi(interval);
        x_train=phi(1:ns(TT),:);
        y_train=yphi(1:ns(TT));
        lTT=randi(nstructure);
        parameters.structure=structure_candidate{lTT};
        
%         xt=phi;
%         yt=yphi;
        
        [B, weights, id_var_bb, stem_B, adjacency_matrix, id_layer, lof, err, stds, lambda_opt] = forward(x_train, y_train, parameters);
        
        
        num_nodes=size(stem_B,1);
        pos_row_id = find(stem_B(:,1)>0);  %positive row index, the rows for the first hidden layer are zero
        if isempty(pos_row_id)   % all the neurons are in the first hidden layer
            num1layer = num_nodes;
        else
            num1layer = num_nodes - length(pos_row_id);  % number of nodes in the first hidden layer
        end
        B_first = cell2mat(B(1:num1layer));  % basis function matrix in the first hidden layer
        
        
        Bs_first{TT} = B_first;
        adjacency_matrices{TT} = adjacency_matrix;
        stem_BBs{TT} = stem_B;
        Bs{TT} = B;
        layer_indices{TT} = id_layer;
        LAYERS{TT}=[B, num2cell(id_layer,2), num2cell(stem_B,2)];
        %     LAYERS=LAYERS';
        weights_all{TT} = weights;
        
        lofs(TT)  = lof;
        errs(TT) = err;
        stds_all(TT) = stds;
        
        yahh1(:,TT) = sys_simulation_ehh(na, nb, uval1, yval1, umin, umax, ymin, ymax, B, stem_B, weights);
        yahh2(:,TT) = sys_simulation_ehh(na, nb, uval2, yval2, umin, umax, ymin, ymax, B, stem_B, weights);
        
        err_test1(TT) = sqrt(norm( yahh1(:,TT) - yval1 )^2/Ntest1);% / norm( yval_multisine - mean( yval_multisine ) )^2;
        std_test1(TT) = std( yahh1(:,TT) - yval1);
        
        err_test2(TT) = sqrt(norm( yahh2(:,TT) - yval2 )^2/Ntest1);% / norm( yval_multisine - mean( yval_multisine ) )^2;
        std_test2(TT) = std( yahh2(:,TT) - yval2);
        
        
        f_ehh_TT(:,TT)=cal_node_value(B,stem_B,x_v)*weights;
        
    end
    P=2*f_ehh_TT'*f_ehh_TT;
    P=(P+P')/2;
    q=-2*f_ehh_TT'*y_v;%y_validate;
    r=y_v'*y_v;%validate;
    lb=zeros(num_train,1);
    [ratio,~]=quadprog(P, q, [], [],[],[],lb, []);
    
    id_non0=find(ratio>1e-5);
    LAYERS = reshape(LAYERS,num_train,1);
    [layers, weights] = merge_net2(LAYERS(id_non0,:), weights_all(id_non0,:), ratio(id_non0), parameters );
    B_tt=layers(:,1);
    stem_B_tt=cell2mat(layers(:,3));
    id_layer_tt=cell2mat(layers(:,2));
    tt( T_gen ) = toc;  % elabsped time for identification
    
%     [sigma, minusgcv] = anova_ehh(layers, weights, x_v, y_v, parameters);
%     [~,bb]=sort(sigma(:,2),'descend');
%     [sigma(bb,:),minusgcv(bb,2)]

    ys1 = sys_simulation_ehh(na, nb, uval1, yval1, umin, umax, ymin, ymax, B_tt, stem_B_tt, weights);
    ys2 = sys_simulation_ehh(na, nb, uval2, yval2, umin, umax, ymin, ymax, B_tt, stem_B_tt, weights);
    
    err_gen1(T_gen) = sqrt(norm(ys1-yval1)^2/Ntest1);
    err_gen2(T_gen) = sqrt(norm(ys2-yval2)^2/Ntest2);
end

figure
plot(yval1(1:5500),'k:','linewidth',1.5)
hold on
plot(ys1(1:5500),'linewidth',1.5)
xlabel('Times Instant','fontsize',14)
ylabel('The outputs','fontsize',14)

figure
plot(yval2(1:5500),'k:','linewidth',1.5)
hold on
plot(ys2(1:5500),'linewidth',1.5)
xlabel('Times Instant','fontsize',14)
ylabel('The outputs','fontsize',14)


