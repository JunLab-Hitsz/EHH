function B_first=ekf_pwl(weights, B_first, stem_B, x_ekf, y_ekf, stds)
%---program for extended Kalman filter updating of the nonlinear parameter
%beta
% x_ekf--   inputs of the training data
% y_ekf--   outputs of the training data, the simplest case is y_ekf\in R^1
% len_alpha=size(coef,1);
len_beta=size(B_first,1);
num_nodes=size(stem_B,1);
beta=B_first(:,3);
dim=size(x_ekf,2);
dim_y=size(y_ekf,2);
R=eye(size(y_ekf,2))*stds^2;%0.01;%*rt^2;%4.5;%2  %!!!this parameter should be tuned
epsilon=1e-10;  % avoid reaching the boundary


% Q1=eye(len_alpha)*1e-6;
Q2=eye(len_beta)*1e-6;
P=eye(len_beta);

% y_pre_ekf=cal_node_value(B_first,stem_B,x_ekf)*weights;
% norm(y_pre_ekf-y_ekf)^2/norm(y_ekf-mean(y_ekf))^2

for k=1:size(x_ekf,1)
    xk=x_ekf(k,:);
    yk=y_ekf(k,:);  %y_train(k,:)'
%     node_values=cal_node_value(B1,stem_B,xk);
    [node_values, affine_nodes, A_beta, b_beta] = cal_node_affine(B_first, stem_B, xk);
    affine_nodes=reshape(affine_nodes,len_beta+1,num_nodes)';
    yhat=node_values*weights;
    B1_values=xk(B_first(:,2))'-B_first(:,3);
   
    Hk=weights(2:end)'*affine_nodes(:,2:end);
    %Kalman filter prediction
    Ak=inv(R+Hk*P*Hk');%H1k'*P1*H1k
    Kk=P*Hk'*Ak;
    gamma=min((b_beta-A_beta*beta+epsilon)./(max(0,A_beta*Kk*(yk-yhat))+1e-10));
    beta=beta+min(gamma,1)*Kk*(yk-yhat);%beta+0.5*Kk*(yk-yhat);
    beta=min(0.99,max(0,beta));  %beta should be in the linear subregion
    P=(eye(len_beta)-Kk*Hk)*P*(eye(len_beta)-Kk*Hk)'+Kk*R*Kk'+Q2;%P-Kk*Hk'*P;%+Q2;
    
    B_first(:,3)=beta;
    cov2_err(k)=trace(P);
end

% y_pre_ekf=cal_node_value(B_first,stem_B,x_ekf)*weights;
% norm(y_pre_ekf-y_ekf)^2/norm(y_ekf-mean(y_ekf))^2


