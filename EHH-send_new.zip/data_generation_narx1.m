function [phi, yphi, u_v, y_v,umin, umax, ymin, ymax]=data_generation_narx1(na,nb,nu,ny,umin, umax, ymin, ymax)
%- na is the assumed lag for u
%- nu is the actual lag for u
%- nb is the assumed lag for y
%- ny is the actual lag for y
%- u and y are all in 1-dimension, for multiple dimensions, later

Lt=8000; % length for train data
Lv=800;  % length for test data
%% train data generation
yout = zeros(Lt, 1);
nu = 2;
ny = 3;
ns1 = max(nu, ny);


for t = 1 : Lt
    u( t ) = unifrnd( -1 , 1 );
end


for t = ns1+1 : Lt
    yout( t ) = ( yout( t - 1 ) * yout( t - 2 ) * yout( t - 3 ) * u( t - 2 ) * ( yout( t - 3 ) - 1 ) + u( t - 1 ) ) / ( 1 + yout( t - 2 )^2 + yout( t - 3 )^2 ) + normrnd( 0, 0.13 );
end


%% test data generation
y_v = zeros(Lv, 1);
u_v = y_v;

for t = 1 : 500
    u_v( t ) = sin( 2 * pi * t / 250);
end
for t = 501 : Lv
    u_v( t ) = 0.8 * sin( 2 * pi * t / 250 ) + 0.2 * sin( 2 * pi * t / 25);
end



for t = ns1+1 : Lv
    y_v( t ) = ( y_v( t - 1 ) * y_v( t - 2 ) * y_v( t - 3 ) * u_v( t - 2 ) * ( y_v( t - 3 ) - 1 ) + u_v( t - 1 ) ) / ( 1 + y_v( t - 2 )^2 + y_v( t - 3 )^2 );% + normrnd( 0 , 0.13 );
end


%% arranged train data
nstart = max(na,nb);
umin = min(u);
umax = max(u);
ymin = min(yout);
ymax = max(yout);
% u = (u-umin)/(umax-umin);
% y = (yout-ymin)/(ymax-ymin);
u = reshape(u,Lt,1);
y = reshape(yout,Lt,1);
for t=nstart+1:Lt
    id=t-nstart;
    reg1 = (y(t-1:-1:t-nb)-ymin)/(ymax - ymin);
    reg2 = (u(t-1:-1:t-na)-umin)/(umax - umin);
    phi(id,:)=[reg1', reg2'];
end
yphi=y(nstart+1: Lt);