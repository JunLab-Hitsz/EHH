clear
close all
%% generate the train data and test data
load('/Users/Jun/Downloads/EHH/data/bouc-wen.mat');
na=10;%1;
nb=15;
dbstop if error

u_interval = [min(u), max(u)];
y_interval = [min(y), max(y)];
uval_multisine = uval_multisine';
yval_multisine = yval_multisine';
uval_sinesweep = uval_sinesweep';
yval_sinesweep = yval_sinesweep';
Ntest1=length(yval_multisine);
Ntest2=length(yval_sinesweep);
ysim1 = zeros(Ntest1, 5);
ysim2 = zeros(Ntest2, 5);

ulag = 1;
u_id = 1:15;%[1 2 3 4 7];
y_id = 1:15;%[1 2 3 4 5 6 7 8 10 11 12];
u = reshape(u,8192,5);
y = reshape(y,8192,5);
% [phi, yphi]=arrange_uy(u(:,5), y(:,5), na, nb, u_interval, y_interval,ulag);
for kk=1:5
[phi, yphi] = arrange_phi(u(:,kk),y(:,kk),u_id, y_id, u_interval, y_interval);

dim = size(phi,2);
Ntrain=length(yphi);


x_train=phi;
y_train=yphi;





%% Parameter Initialiation
config_file = 'config.ini';
parameters = init_par(config_file);
penalty = parameters.penalty;  % complexity penalty
num_train = parameters.num_train;  % number of training
percent = parameters.percent; % percentage of training data
parameters.lambda=[1e-9,1e-8,1e-7,1e-6];%; should be tuned for specific problem?


%%--EHH network optimization--




[B_first, weights, id_var_bb, stem_B, adjacency_matrix, lof0, err0, lambda_opt] = Ini_network(x_train, y_train, parameters);
flag = 1;
[err0, lof0]

tic

while flag
    [stem_B, lof, err]=Structue_optimization2(B_first, stem_B, adjacency_matrix, id_var_bb, weights, x_train,y_train,err0, parameters);
    %         [~, yahh] = sys_simulation_ehh(na, nb, u_v, B_first, stem_B, weights, u_interval, y_interval,ulag);
    %         sqrt(norm( yahh - y_test )^2 / Ntest)%norm( y_test - mean( y_test ) )^2;%sqrt(/Ntest);%
    [ err, lof]
    [B_first, BB, stem_B, adjacency_matrix, id_var_bb, weights, lof, err]=weights_optimization(B_first, stem_B, id_var_bb, x_train, y_train, lambda_opt, parameters);
    %         [~, yahh] = sys_simulation_ehh(na, nb, u_v, B_first, stem_B, weights, u_interval, y_interval,ulag);
    %         sqrt(norm( yahh - y_test )^2 / Ntest)%norm( y_test - mean( y_test ) )^2;%sqrt(/Ntest);%
    [ err, lof ]
    if lof<lof0
        flag = 1;
        lof0 = lof;
        err0 = err;
    else
        flag = 0;
    end
end

toc

% [~,ysim1] = sys_simulation_ehh(na, nb, uval_multisine, B_first, stem_B, weights, u_interval, y_interval,ulag);
[~,ysim1(:, kk)] = sys_simulation_ehh_phi(u_id, y_id, uval_multisine, B_first, stem_B, weights, u_interval, y_interval);
% [~,ysim2] = sys_simulation_ehh(na, nb, uval_sinesweep, B_first, stem_B, weights, u_interval, y_interval,ulag);
[~,ysim2(:, kk)] = sys_simulation_ehh_phi(u_id, y_id, uval_sinesweep, B_first, stem_B, weights, u_interval, y_interval);
end
err_sim1 = sqrt(norm(mean(ysim1,2)-yval_multisine)^2/Ntest1)
err_sim2 = sqrt(norm(mean(ysim2,2)-yval_sinesweep)^2/Ntest2)

%     [sigma, minusgcv] = anova_ehh(layers, weights, phi, yphi, parameters);
%     [~,bb]=sort(sigma(:,2),'descend');
%     [sigma(bb,:),minusgcv(bb,2)]



% err_gen(T_gen)=err_test;%norm(y_test-mean(y_test))^2;
% rsse(T_gen) = norm(yahh-y_test)^2/norm(y_test-mean(y_test))^2;
% 
% 
% figure
% plot(y_test,'k:','linewidth',1.5)
% hold on
% plot(yahh,'linewidth',1.5)
% xlabel('Times Instant','fontsize',14)
% ylabel('The outputs','fontsize',14)
% 
% 
% 

