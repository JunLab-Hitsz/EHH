%--ex_narx.m---
clear
close all
% generate the train data and test data
% load('/Users/Jun/Downloads/EHH/data/narx1-auto.mat');
nu=1;ny=1;  % is fixed for each nonlinear system

na=2;
nb=1;
% umin=-1; umax=1;
% ymin=-1.5; ymax=1.5;
dbstop if error

for T_gen=1:10
    
    [phi, yphi, u_v, y_test,umin, umax, ymin, ymax]=data_generation_narx2(na,nb);
    %     [phi, yphi, u_v, y_test,umin, umax, ymin, ymax]=data_generation_narx1(na,nb);
    u_interval = [umin, umax];
    y_interval = [ymin, ymax];
    ulag = 1;
    dim = size(phi,2);
    dim_y = size(yphi,1);
    Ntrain=length(yphi);
    Ntest=length(y_test);
    
    
    %% Parameter Initialiation
    config_file = 'config.ini';
    parameters = init_par(config_file);
    penalty = parameters.penalty;  % complexity penalty
    num_train = parameters.num_train;  % number of training
    percent = parameters.percent; % percentage of training data
    parameters.lambda=[1e-2, 1e-1,1];%, 1e-2, 1e-1];%; should be tuned for specific problem?
    
    
    
    
    yahh = zeros(length(y_test), 1);
    
    tic
    
    x_train=phi;
    y_train=yphi;
    
    
    [B_first, weights, id_var_bb, stem_B, adjacency_matrix, lof0, err0, lambda_opt] = Ini_network(x_train, y_train, parameters);
    flag = 1;
    [err0, lof0]
    
    while flag
        [stem_B, adjacency_matrix, lof, err]=Structue_optimization(B_first, stem_B, adjacency_matrix, id_var_bb, weights, x_train,y_train,err0, parameters);
%         [~, yahh] = sys_simulation_ehh(na, nb, u_v, B_first, stem_B, weights, u_interval, y_interval,ulag);
%         sqrt(norm( yahh - y_test )^2 / Ntest)%norm( y_test - mean( y_test ) )^2;%sqrt(/Ntest);%
        [ err, lof]
        [B_first, BB, stem_B, adjacency_matrix, id_var_bb, weights, lof, err]=weights_optimization(B_first, stem_B, id_var_bb, x_train, y_train, lambda_opt/10, parameters);
%         [~, yahh] = sys_simulation_ehh(na, nb, u_v, B_first, stem_B, weights, u_interval, y_interval,ulag);
%         sqrt(norm( yahh - y_test )^2 / Ntest)%norm( y_test - mean( y_test ) )^2;%sqrt(/Ntest);%
        [ err, lof ]
        if lof<lof0
            flag = 1;
            lof0 = lof;
            err0 = err;
        else
            flag = 0;
        end
    end
    
    
    
    
    [~, yahh] = sys_simulation_ehh(na, nb, u_v, B_first, stem_B, weights, u_interval, y_interval,ulag);
    err_test= sqrt(norm( yahh - y_test )^2 / Ntest)%norm( y_test - mean( y_test ) )^2;%sqrt(/Ntest);%
    std_test = std( yahh - y_test);
    
    %     [sigma, minusgcv] = anova_ehh(layers, weights, phi, yphi, parameters);
    %     [~,bb]=sort(sigma(:,2),'descend');
    %     [sigma(bb,:),minusgcv(bb,2)]
    
    
    
    err_gen(T_gen)=err_test;%norm(y_test-mean(y_test))^2;
    rsse(T_gen) = norm(yahh-y_test)^2/norm(y_test-mean(y_test))^2;
    
    time_gen(T_gen)=toc;
end

figure
plot(y_test,'k:','linewidth',1.5)
hold on
plot(yahh,'linewidth',1.5)
xlabel('Times Instant','fontsize',14)
ylabel('The outputs','fontsize',14)




